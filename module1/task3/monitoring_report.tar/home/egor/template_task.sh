#!/bin/bash


echo "[$$] $(date '+%Y-%m-%d %H:%M:%S') Скрипт запущен" >> report_template_task.log
random_seconds=$(( RANDOM % 1771 + 30 ))
sleep_minutes=$(( random_seconds / 60 ))
sleep "$random_seconds"
echo "[$$] $(date '+%Y-%m-%d %H:%M:%S') Скрипт завершился, работал $sleep_minutes минут" >> report_template_task.log
