#!/bin/bash

config_file="$HOME/task2/config.txt"
log_file="observer.log"
scripts_dir="$HOME"

start_script() {
    nohup "$scripts_dir/$1" >/dev/null 2>&1 &
    echo "$(date '+%Y-%m-%d %H:%M:%S') [INFO] Запущен $1 (PID: $!)" >> "$log_file"
}

while IFS= read -r script_name || [ -n "$script_name" ]; do
    [[ -z "$script_name" || "$script_name" =~ ^# ]] && continue

    if [ ! -f "$scripts_dir/$script_name" ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') [ERROR] Скрипт $script_name не найден в $scripts_dir" >> "$log_file"
        continue
    fi

    if ! pgrep -f "$script_name" >/dev/null; then
        start_script "$script_name"
    fi
done < "$config_file"
